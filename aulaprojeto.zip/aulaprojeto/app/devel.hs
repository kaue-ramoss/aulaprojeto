{-# LANGUAGE PackageImports #-}
import "aulaprojeto" Application (develMain)
import Prelude (IO)

main :: IO ()
main = develMain
