import Prelude     (IO)
import Application (appMain)

main :: IO ()
main = appMain
